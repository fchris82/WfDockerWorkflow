<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2017.09.08.
 * Time: 16:54.
 */

namespace App\Wizard\Helper;

use Symfony\Component\Console\Output\OutputInterface;

class ComposerInstaller
{
    const COMPOSER_NODEV = 'nodev';
    const COMPOSER_DEV = 'dev';
}
