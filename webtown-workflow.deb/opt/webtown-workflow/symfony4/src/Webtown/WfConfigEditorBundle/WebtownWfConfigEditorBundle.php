<?php

declare(strict_types=1);
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2019.02.21.
 * Time: 12:50
 */

namespace App\Webtown\WfConfigEditorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WebtownWfConfigEditorBundle extends Bundle
{
}
