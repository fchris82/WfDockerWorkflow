<?php

declare(strict_types=1);
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2019.01.18.
 * Time: 20:28
 */

namespace App\Webtown\WfBaseSystemRecipesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WebtownWfBaseSystemRecipesBundle extends Bundle
{
}
