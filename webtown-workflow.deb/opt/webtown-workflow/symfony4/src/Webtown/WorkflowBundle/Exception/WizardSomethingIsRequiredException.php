<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.11.15.
 * Time: 12:14
 */

namespace App\Webtown\WorkflowBundle\Exception;

class WizardSomethingIsRequiredException extends \Exception
{
}
