<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.12.02.
 * Time: 17:53
 */

namespace App\Webtown\WorkflowBundle\Exception\Extension;

class UnknownSourceTypeException extends InvalidSourceException
{
}
