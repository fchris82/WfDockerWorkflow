<?php

declare(strict_types=1);
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.11.30.
 * Time: 12:54
 */

namespace App\Webtown\WorkflowBundle\Exception;

class ValueIsMissingException extends \Exception
{
}
