<?php

declare(strict_types=1);
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.10.18.
 * Time: 10:25
 */

namespace App\Webtown\WorkflowBundle\Exception;

/**
 * Class SkipSkeletonFileException
 *
 * You can skip a skeletonfile
 */
class SkipSkeletonFileException extends \Exception
{
}
