<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.12.02.
 * Time: 18:01
 */

namespace App\Webtown\WorkflowBundle\Exception\Extension;

class UnknownOrInvalidExtension extends ExtensionException
{
}
