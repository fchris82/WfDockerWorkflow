<?php

declare(strict_types=1);
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.03.28.
 * Time: 17:10
 */

namespace App\Webtown\WorkflowBundle\Exception;

class MissingRecipeException extends \Exception
{
}
