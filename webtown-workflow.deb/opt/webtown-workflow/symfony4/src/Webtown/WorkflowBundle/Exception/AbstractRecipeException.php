<?php

declare(strict_types=1);
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.04.18.
 * Time: 12:12
 */

namespace App\Webtown\WorkflowBundle\Exception;

class AbstractRecipeException extends \Exception
{
}
