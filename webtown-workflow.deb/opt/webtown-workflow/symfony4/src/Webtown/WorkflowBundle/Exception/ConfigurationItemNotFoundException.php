<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.11.13.
 * Time: 15:35
 */

namespace App\Webtown\WorkflowBundle\Exception;

class ConfigurationItemNotFoundException extends \Exception
{
}
