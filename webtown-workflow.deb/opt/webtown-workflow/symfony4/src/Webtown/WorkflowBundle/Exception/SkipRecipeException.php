<?php

declare(strict_types=1);
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.03.27.
 * Time: 11:38
 */

namespace App\Webtown\WorkflowBundle\Exception;

/**
 * Class SkipRecipeException
 *
 * You can skip a recipe if you want with this.
 */
class SkipRecipeException extends \Exception
{
}
