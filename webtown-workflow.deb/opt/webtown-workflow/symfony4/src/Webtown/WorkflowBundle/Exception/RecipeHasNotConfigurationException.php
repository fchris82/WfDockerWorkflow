<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2019.01.21.
 * Time: 12:00
 */

namespace App\Webtown\WorkflowBundle\Exception;

class RecipeHasNotConfigurationException extends \Exception
{
}
