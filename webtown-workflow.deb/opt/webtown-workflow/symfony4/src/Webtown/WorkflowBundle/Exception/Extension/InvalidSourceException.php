<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.12.02.
 * Time: 17:51
 */

namespace App\Webtown\WorkflowBundle\Exception\Extension;

class InvalidSourceException extends ExtensionException
{
}
