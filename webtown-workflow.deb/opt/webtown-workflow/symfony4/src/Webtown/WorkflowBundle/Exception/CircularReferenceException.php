<?php

declare(strict_types=1);
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.11.12.
 * Time: 13:12
 */

namespace App\Webtown\WorkflowBundle\Exception;

class CircularReferenceException extends \Exception
{
}
