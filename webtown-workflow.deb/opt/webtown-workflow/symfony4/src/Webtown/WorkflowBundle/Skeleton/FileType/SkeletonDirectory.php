<?php

declare(strict_types=1);
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.11.27.
 * Time: 11:19
 */

namespace App\Webtown\WorkflowBundle\Skeleton\FileType;

class SkeletonDirectory extends SkeletonFile
{
}
