<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2019.01.18.
 * Time: 10:59
 */

namespace App\Webtown\WorkflowBundle\Tests\Resources\DependencyInjection\SimpleRecipe;

class SimpleRecipe
{
}
