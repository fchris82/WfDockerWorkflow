<?php

namespace App\Webtown\WorkflowBundle\DependencyInjection\Compiler;

use App\Webtown\WorkflowBundle\WebtownWorkflowBundle;
use App\Webtown\WorkflowBundle\Wizard\Manager;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;

class CollectWizardsPass extends AbstractTwigSkeletonPass
{
    /**
     * You can modify the container here before it is dumped to PHP code.
     */
    public function process(ContainerBuilder $container)
    {
        $definition = $container->getDefinition(Manager::class);
        $twigFilesystemLoaderDefinition = $container->getDefinition(parent::DEFAULT_TWIG_LOADER);

        foreach ($container->findTaggedServiceIds(WebtownWorkflowBundle::WIZARD_TAG) as $serviceId => $taggedService) {
            $definition->addMethodCall('addWizard', [new Reference($serviceId)]);

            $serviceDefinition = $container->getDefinition($serviceId);
            $this->registerSkeletonService($serviceDefinition, $twigFilesystemLoaderDefinition);
        }
    }
}
