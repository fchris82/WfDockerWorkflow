MailHog
=======

Project repository: https://github.com/mailhog/MailHog

| Port | Service |
|:---- |:------- |
| `1025` | SMTP |
| `8025` | Web UI |

There is no way to set other ports. I got "permission denied" message.
