<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.03.29.
 * Time: 15:23
 */

namespace App\Recipes\SymfonyEz1;

use App\Recipes\Symfony2\Symfony2Recipe;

class SymfonyEz1Recipe extends Symfony2Recipe
{
    const NAME = 'symfony_ez1';
    const DEFAULT_VERSION = 'ez1';
}
