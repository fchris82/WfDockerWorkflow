<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.03.24.
 * Time: 22:01
 */

namespace App\Skeleton;

class DockerComposeSkeletonFile extends SkeletonFile
{
}
