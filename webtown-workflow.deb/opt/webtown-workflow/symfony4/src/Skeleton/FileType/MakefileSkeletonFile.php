<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.03.24.
 * Time: 22:00
 */

namespace App\Skeleton\FileType;

class MakefileSkeletonFile extends SkeletonFile
{
}
