<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.11.27.
 * Time: 11:19
 */

namespace App\Skeleton\FileType;

class SkeletonDirectory extends SkeletonFile
{
}
