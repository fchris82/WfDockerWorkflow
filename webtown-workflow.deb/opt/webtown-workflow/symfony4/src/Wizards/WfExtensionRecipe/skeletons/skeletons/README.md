{{ recipe_class }}
{{ recipe_class | md_underline }}

<!-- TODO -->
