{{ name|default('<name>') }} wizard
===================================

This project was created by <creator> .

## Install

This is a WF wizard, first of all you have to install the WF framework, if you haven't done it yet.

Then run:

```shell
$ wizard --install [composer package name|git repository]
```

## Usage
