<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.12.02.
 * Time: 19:32
 */

namespace App\Extension;

interface ExtensionInterface
{
    public function getExtensionName();

    public function getExtensionType();
}
