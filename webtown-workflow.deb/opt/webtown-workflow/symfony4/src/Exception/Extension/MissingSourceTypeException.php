<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.12.02.
 * Time: 17:52
 */

namespace App\Exception\Extension;

class MissingSourceTypeException extends InvalidSourceException
{
}
