<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.12.02.
 * Time: 18:09
 */

namespace App\Exception\Extension;

class UnknownOrInvalidNamespace extends ExtensionException
{
}
