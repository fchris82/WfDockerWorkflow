<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2017.08.11.
 * Time: 17:09.
 */

namespace App\Exception;

class ProjectHasDecoratedException extends \Exception
{
}
