<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.10.18.
 * Time: 10:25
 */

namespace App\Exception;

/**
 * Class SkipSkeletonFileException
 *
 * You can skip a skeletonfile
 *
 * @package App\Exception
 */
class SkipSkeletonFileException extends \Exception
{
}
