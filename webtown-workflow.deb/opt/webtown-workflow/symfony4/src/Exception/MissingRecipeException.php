<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.03.28.
 * Time: 17:10
 */

namespace App\Exception;

class MissingRecipeException extends \Exception
{
}
