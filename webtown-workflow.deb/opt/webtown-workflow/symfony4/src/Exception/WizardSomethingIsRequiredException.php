<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.11.15.
 * Time: 12:14
 */

namespace App\Exception;


class WizardSomethingIsRequiredException extends \Exception
{

}
