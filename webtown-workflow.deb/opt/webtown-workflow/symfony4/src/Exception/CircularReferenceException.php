<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.11.12.
 * Time: 13:12
 */

namespace App\Exception;

class CircularReferenceException extends \Exception
{
}
