<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.03.29.
 * Time: 15:23
 */

namespace Recipes\SymfonyEz1;

use Recipes\Symfony2\Recipe as Symfony2Recipe;

class Recipe extends Symfony2Recipe
{
    const NAME = 'symfony_ez1';
}
