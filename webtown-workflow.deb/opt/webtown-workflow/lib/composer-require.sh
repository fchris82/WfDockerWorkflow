#!/bin/bash
# Debug mode:
#set -x

cd /opt/webtown-workflow/symfony4
composer reuire ${@}
