The `host` directory
====================

This directory contains the files for host computer.

## `copy_binaries_to_host.sh`

This file copy FROM docker container TO host computer the binaries!
