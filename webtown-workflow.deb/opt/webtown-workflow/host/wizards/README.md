Custom wizards
==============

You can use your own custom wizards. Insert directly or with symlink your recipes in this directory, and the program will
insert these automatically.
