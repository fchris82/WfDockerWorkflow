<?php
/**
 * Created by IntelliJ IDEA.
 * User: chris
 * Date: 2018.03.28.
 * Time: 17:10
 */

namespace AppBundle\Exception;

class MissingRecipeException extends \Exception
{
}
