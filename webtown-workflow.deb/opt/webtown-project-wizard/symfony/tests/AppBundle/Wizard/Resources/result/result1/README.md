# Install

    wf init
    
    # Edit the dist files!!!
    
    wf install

# Project information

    wf help

